# EBITDA Calculator - Frontend

OPENDART API 기반 기업 EBITDA 분석 웹 애플리케이션

## 🎨 주요 기능

### ✅ 구현된 기능
- **검색 기능**: 회사명 또는 종목코드로 검색
- **연도/보고서 선택**: 드롭다운으로 사업연도, 보고서 유형, 재무제표 구분 선택
- **결과 테이블**: EBITDA 구성요소를 표 형식으로 시각화
- **시계열 차트**: 최근 5년 EBITDA 추이 (라인/막대 차트 전환)
- **EBITDA 정의 패널**: 개념, 계산식, 주의사항을 화면에 고정 표시
- **에러 처리**: 친화적인 에러 메시지와 재시도 옵션
- **경고 시스템**: 누적/당기 금액, 데이터 품질 이슈 알림
- **반응형 디자인**: 모바일, 태블릿, 데스크톱 대응

### 📊 화면 구성
```
┌─────────────────────────────────────────────────┐
│              헤더 (타이틀, 로고)                   │
├──────────────────────┬──────────────────────────┤
│                      │                          │
│  검색 폼              │  EBITDA 정의 패널         │
│  (회사, 연도, 보고서)  │  (sticky, 스크롤 고정)    │
│                      │                          │
├──────────────────────┤  - EBITDA란?             │
│                      │  - 계산 공식              │
│  경고 메시지          │  - 구성요소 설명          │
│                      │  - 주의사항 (누적/당기)   │
├──────────────────────┤  - 활용 사례             │
│                      │                          │
│  결과 테이블          │                          │
│  (EBITDA 구성요소)    │                          │
│                      │                          │
├──────────────────────┤                          │
│                      │                          │
│  시계열 차트          │                          │
│  (최근 5년 추이)      │                          │
│                      │                          │
└──────────────────────┴──────────────────────────┘
```

## 📁 프로젝트 구조

```
ebitda-frontend/
├── src/
│   ├── app/
│   │   ├── layout.tsx          # 루트 레이아웃
│   │   ├── page.tsx            # 메인 페이지
│   │   └── globals.css         # 글로벌 스타일
│   ├── components/
│   │   ├── SearchForm.tsx      # 검색 폼
│   │   ├── ResultTable.tsx     # 결과 테이블
│   │   ├── TimeSeriesChart.tsx # 시계열 차트
│   │   ├── EBITDAInfoPanel.tsx # EBITDA 정보 패널
│   │   ├── WarningAlerts.tsx   # 경고 메시지
│   │   ├── ErrorDisplay.tsx    # 에러 화면
│   │   └── EmptyState.tsx      # 빈 상태
│   ├── lib/
│   │   ├── api.ts              # API 클라이언트
│   │   └── utils.ts            # 유틸리티 함수
│   └── types/
│       └── index.ts            # TypeScript 타입
├── public/                     # 정적 파일
├── package.json
├── tsconfig.json
├── next.config.js
├── tailwind.config.js
└── README.md
```

## 🚀 빠른 시작

### 1. 의존성 설치

```bash
npm install
```

### 2. 환경변수 설정

`.env.local` 파일 생성:

```bash
NEXT_PUBLIC_API_URL=http://localhost:8000
```

### 3. 개발 서버 실행

```bash
npm run dev
```

브라우저에서 http://localhost:3000 접속

### 4. 백엔드 API 서버 실행

별도 터미널에서 백엔드 실행:

```bash
cd ../ebitda-api
uvicorn app.main:app --reload --port 8000
```

## 🎯 사용 방법

### 기본 검색

1. **회사명 또는 종목코드** 입력
   - 예: "삼성전자" 또는 "005930"
   
2. **사업연도** 선택
   - 최근 10년 중 선택
   
3. **보고서 유형** 선택
   - 사업보고서 (연간)
   - 반기보고서
   - 1분기보고서
   - 3분기보고서
   
4. **재무제표 구분** 선택
   - 연결재무제표 (기본값)
   - 개별재무제표

5. **"EBITDA 조회"** 버튼 클릭

### 결과 확인

#### 결과 테이블
- **영업이익**: 본업에서 창출한 이익
- **감가상각비**: 유형자산 가치 감소분
- **무형자산상각비**: 무형자산 가치 감소분
- **총 EBITDA**: 위 3가지 합계
- 각 항목의 비율 표시

#### 시계열 차트
- 최근 5년간 EBITDA 추이
- 라인 차트 / 막대 차트 전환 가능
- 모든 구성요소 동시 표시
- 호버 시 상세 정보 표시

#### 경고 메시지
- 누적/당기 금액 기준 안내
- 데이터 품질 이슈 경고
- 계정 누락 알림

## 🛠️ 기술 스택

### 프레임워크 & 라이브러리
- **Next.js 14**: React 프레임워크 (App Router)
- **TypeScript**: 타입 안정성
- **Tailwind CSS**: 유틸리티 기반 스타일링
- **Recharts**: 차트 라이브러리
- **Axios**: HTTP 클라이언트
- **Lucide React**: 아이콘

### 주요 기능
- **Client-side Rendering**: 동적 데이터 처리
- **Responsive Design**: 모든 디바이스 대응
- **Error Boundaries**: 에러 격리
- **Loading States**: 로딩 상태 관리
- **Optimistic UI**: 빠른 사용자 피드백

## 🎨 디자인 시스템

### 색상 팔레트
- **Primary**: Blue (#3b82f6)
- **Success**: Green (#10b981)
- **Warning**: Yellow (#f59e0b)
- **Error**: Red (#ef4444)
- **Neutral**: Gray (#6b7280)

### 컴포넌트 스타일
- **카드**: 흰색 배경, 그림자, 둥근 모서리
- **버튼**: Primary 색상, 호버 효과
- **입력 필드**: 테두리, 포커스 링
- **표**: 호버 효과, 교차 배경

## 📱 반응형 브레이크포인트

```css
- sm: 640px   /* 모바일 (큰 화면) */
- md: 768px   /* 태블릿 */
- lg: 1024px  /* 데스크톱 */
- xl: 1280px  /* 큰 데스크톱 */
```

## 🔧 개발 가이드

### 새 컴포넌트 추가

```tsx
// src/components/NewComponent.tsx
'use client';

import { useState } from 'react';

interface NewComponentProps {
  // props 정의
}

export default function NewComponent({ }: NewComponentProps) {
  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      {/* 컴포넌트 내용 */}
    </div>
  );
}
```

### API 호출 추가

```tsx
// src/lib/api.ts
export async function fetchNewData(params: any) {
  const response = await apiClient.get('/api/v1/endpoint', { params });
  return response.data;
}
```

### 타입 정의 추가

```tsx
// src/types/index.ts
export interface NewType {
  field1: string;
  field2: number;
}
```

## 🧪 테스트

### 수동 테스트 시나리오

1. **정상 케이스**
   - 삼성전자 2024년 3분기 조회
   - 결과 테이블 확인
   - 시계열 차트 확인

2. **에러 케이스**
   - 존재하지 않는 회사명 입력
   - 데이터 없는 연도 선택
   - API 서버 중지 후 조회

3. **반응형 테스트**
   - 모바일 뷰 (375px)
   - 태블릿 뷰 (768px)
   - 데스크톱 뷰 (1920px)

## 🚀 프로덕션 배포

### 빌드

```bash
npm run build
```

### 실행

```bash
npm start
```

### 환경변수 설정

프로덕션 환경에서는 실제 API URL 설정:

```bash
NEXT_PUBLIC_API_URL=https://api.example.com
```

## 📊 성능 최적화

- **코드 스플리팅**: 자동 페이지별 분할
- **이미지 최적화**: Next.js Image 컴포넌트
- **CSS 최적화**: Tailwind CSS Purge
- **캐싱**: API 응답 캐싱 (백엔드)

## 🐛 알려진 이슈

- 자동완성 기능은 향후 업데이트 예정
- 일부 기업의 감가상각비 데이터가 누락될 수 있음

## 📝 라이선스

MIT License

## 🤝 기여

Issue 및 Pull Request 환영합니다!
