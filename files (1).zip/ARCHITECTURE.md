# 📁 프로젝트 구조

```
ebitda-api/
│
├── app/                                # 애플리케이션 코드
│   ├── __init__.py
│   ├── main.py                         # FastAPI 엔트리포인트 (117줄)
│   ├── config.py                       # 환경변수 설정 관리 (35줄)
│   ├── models.py                       # Pydantic 데이터 모델 (80줄)
│   │
│   ├── services/                       # 비즈니스 로직
│   │   ├── __init__.py
│   │   ├── dart_client.py              # OPENDART API 클라이언트 (149줄)
│   │   ├── corp_resolver.py            # corp_code 매핑 서비스 (147줄)
│   │   ├── financial_service.py        # 재무정보 조회 서비스 (118줄)
│   │   └── ebitda_calculator.py        # EBITDA 계산 로직 (207줄)
│   │
│   ├── utils/                          # 유틸리티
│   │   ├── __init__.py
│   │   ├── cache.py                    # SQLite 캐싱 시스템 (132줄)
│   │   └── rate_limiter.py             # Rate Limiting 유틸리티 (101줄)
│   │
│   └── routers/                        # API 라우터
│       ├── __init__.py
│       └── ebitda.py                   # EBITDA API 엔드포인트 (130줄)
│
├── data/                               # 데이터 저장소
│   └── cache/                          # 캐시 디렉토리
│       ├── cache.db                    # SQLite 캐시 DB (자동 생성)
│       └── corp_code.xml               # 고유번호 매핑 (자동 다운로드)
│
├── .env                                # 환경변수 (API 키 등)
├── .env.example                        # 환경변수 템플릿
├── requirements.txt                    # Python 의존성
├── README.md                           # 프로젝트 설명
├── QUICKSTART.md                       # 빠른 시작 가이드
└── test_api.sh                         # API 테스트 스크립트

```

## 핵심 파일 설명

### 📄 main.py (117줄)
- FastAPI 애플리케이션 초기화
- 라우터 등록
- CORS 미들웨어 설정
- 생명주기 관리 (lifespan)

### 📄 config.py (35줄)
- 환경변수 로드 (.env)
- 설정 싱글톤 제공
- 캐시 디렉토리 자동 생성

### 📄 models.py (80줄)
- Pydantic 모델 정의
- API 요청/응답 스키마
- 데이터 검증

### 📄 dart_client.py (149줄)
- OPENDART API HTTP 클라이언트
- Rate limiting 통합
- Exponential backoff 재시도
- 에러 코드 사용자 친화 메시지 변환

### 📄 corp_resolver.py (147줄)
- corpCode.xml 다운로드 및 파싱
- 회사명/종목코드 → corp_code 매핑
- 로컬 캐싱 (30일 TTL)
- 부분 일치 검색 지원

### 📄 financial_service.py (118줄)
- 재무정보 API 호출
- SQLite 캐싱
- 계정 추출 유틸리티

### 📄 ebitda_calculator.py (207줄)
- EBITDA 계산 로직
- 영업이익/감가상각비/무형자산상각비 추출
- 당기/누적 금액 자동 판단
- 경고 메시지 생성

### 📄 cache.py (132줄)
- SQLite 기반 캐싱 시스템
- 자동 만료 처리
- 해시 기반 키 생성

### 📄 rate_limiter.py (101줄)
- 토큰 버킷 알고리즘
- 비동기 Rate limiting
- Exponential backoff

### 📄 ebitda.py (130줄)
- `/api/v1/ebitda` 엔드포인트
- 요청 검증 (Query params)
- 에러 핸들링
- 응답 구성

## 데이터 플로우

```
사용자 요청
    ↓
[ebitda.py] API 엔드포인트
    ↓
[corp_resolver.py] 회사명/종목코드 → corp_code 변환
    ↓
[ebitda_calculator.py] EBITDA 계산 시작
    ↓
[financial_service.py] 재무정보 조회
    ├─ [cache.py] 캐시 확인
    └─ [dart_client.py] OPENDART API 호출
            ├─ [rate_limiter.py] Rate limiting
            └─ Exponential backoff 재시도
    ↓
[ebitda_calculator.py] EBITDA 계산
    ├─ 영업이익 추출 (손익계산서)
    ├─ 감가상각비 추출 (현금흐름표)
    ├─ 무형자산상각비 추출 (현금흐름표)
    └─ EBITDA = 합계
    ↓
[ebitda.py] 응답 구성 및 반환
    ↓
JSON 응답
```

## 캐싱 전략

### 1. corp_code 매핑 (파일 캐시)
- 위치: `data/cache/corp_code.xml`
- TTL: 30일
- 크기: ~15MB (압축 해제 후)
- 갱신: 최초 1회 + 30일마다

### 2. 재무정보 (SQLite 캐시)
- 위치: `data/cache/cache.db`
- TTL: 30일 (설정 가능)
- 키: SHA256(corp_code, year, report_code, fs_div)
- 자동 만료 정리

## Rate Limiting

- 기본값: 초당 5회
- 알고리즘: 토큰 버킷
- 재시도: Exponential backoff (최대 3회)
- 백오프 딜레이: 1초 → 2초 → 4초

## 에러 처리

| 에러 코드 | HTTP 상태 | 설명 |
|---------|----------|------|
| 000 | 200 | 정상 응답 |
| 010 | 401 | 등록되지 않은 API 키 |
| 013 | 404 | 데이터 없음 |
| 020 | 429 | 요청 제한 초과 |
| 100 | 400 | 잘못된 파라미터 |
| 800 | 403 | 접속 차단 |

## 코드 통계

- 총 라인 수: ~1,150줄
- Python 파일: 13개
- 설정 파일: 4개
- 문서 파일: 3개
